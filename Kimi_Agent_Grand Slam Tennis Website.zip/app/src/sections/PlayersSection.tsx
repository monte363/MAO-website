import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, TrendingUp } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const players = [
  {
    id: 1,
    name: 'Emma Wilson',
    country: 'GBR',
    rank: 3,
    image: '/player-1.jpg',
  },
  {
    id: 2,
    name: 'Alexander Kovac',
    country: 'SRB',
    rank: 1,
    image: '/player-2.jpg',
  },
  {
    id: 3,
    name: 'Sofia Martinez',
    country: 'ESP',
    rank: 5,
    image: '/player-3.jpg',
  },
  {
    id: 4,
    name: 'James Park',
    country: 'USA',
    rank: 7,
    image: '/player-4.jpg',
  },
  {
    id: 5,
    name: 'Yuki Tanaka',
    country: 'JPN',
    rank: 12,
    image: '/player-5.jpg',
  },
  {
    id: 6,
    name: 'Marcus Chen',
    country: 'USA',
    rank: 2,
    image: '/player-6.jpg',
  },
];

export default function PlayersSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        '.players-title',
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Player cards animation
      const cards = sectionRef.current?.querySelectorAll('.player-card');
      cards?.forEach((card, index) => {
        gsap.fromTo(
          card,
          { scale: 0, rotate: -10, opacity: 0 },
          {
            scale: 1,
            rotate: 0,
            opacity: 1,
            duration: 0.6,
            delay: 0.2 + index * 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 300;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section ref={sectionRef} className="py-20 bg-tennis-light overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="players-title flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <h2 className="section-title mb-4">Meet The Players</h2>
            <p className="text-gray-600 max-w-lg">
              Discover the world-class athletes competing for championship glory 
              at this year's Grand Slam tournament.
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => scroll('left')}
              className="p-3 bg-white rounded-full shadow-md transition-all duration-300 hover:bg-tennis-dark hover:text-white"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="p-3 bg-white rounded-full shadow-md transition-all duration-300 hover:bg-tennis-dark hover:text-white"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Players Carousel */}
        <div
          ref={scrollContainerRef}
          className="flex gap-6 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {players.map((player) => (
            <div
              key={player.id}
              className="player-card group flex-shrink-0 w-64 snap-start"
            >
              <div className="relative overflow-hidden rounded-2xl bg-white shadow-lg transition-all duration-500 hover:-translate-y-2 hover:shadow-xl">
                {/* Image */}
                <div className="relative h-80 overflow-hidden">
                  <img
                    src={player.image}
                    alt={player.name}
                    className="w-full h-full object-cover transition-all duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-tennis-dark via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />
                  
                  {/* Rank Badge */}
                  <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-full">
                    <TrendingUp className="w-4 h-4 text-tennis-accent" />
                    <span className="font-oswald text-sm font-semibold text-tennis-dark">
                      Rank #{player.rank}
                    </span>
                  </div>

                  {/* Player Info */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                    <h3 className="font-oswald text-xl text-white uppercase mb-1">
                      {player.name}
                    </h3>
                    <p className="text-white/70 text-sm">{player.country}</p>
                    
                    {/* View Profile Link */}
                    <Link
                      to="/players"
                      className="inline-flex items-center gap-2 mt-4 text-tennis-gold font-oswald text-sm uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    >
                      View Profile
                      <ChevronRight className="w-4 h-4" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Link */}
        <div className="text-center mt-12">
          <Link
            to="/players"
            className="inline-flex items-center gap-3 bg-tennis-dark text-white px-8 py-4 font-oswald uppercase tracking-wider text-sm rounded transition-all duration-300 hover:bg-tennis-accent hover:scale-[1.02]"
          >
            View All Players
            <ChevronRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
