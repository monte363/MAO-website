import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Link } from 'react-router-dom';
import { Play, ArrowRight, Eye, Clock } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const videos = [
  {
    id: 1,
    title: 'Finals Highlights: Championship Point',
    thumbnail: '/video-1.jpg',
    duration: '8:45',
    views: '2.4M',
    featured: true,
  },
  {
    id: 2,
    title: 'Top 10 Shots of the Tournament',
    thumbnail: '/video-2.jpg',
    duration: '5:32',
    views: '1.8M',
    featured: false,
  },
  {
    id: 3,
    title: 'Player Interviews: Post-Match Reactions',
    thumbnail: '/video-3.jpg',
    duration: '12:18',
    views: '956K',
    featured: false,
  },
];

export default function VideosSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Header animation
      gsap.fromTo(
        '.videos-header',
        { x: -50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Featured video animation
      gsap.fromTo(
        '.featured-video',
        { scale: 0.9, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.8,
          delay: 0.2,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );

      // Small videos animation
      gsap.fromTo(
        '.small-video',
        { x: 50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.15,
          delay: 0.4,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const featuredVideo = videos.find((v) => v.featured);
  const smallVideos = videos.filter((v) => !v.featured);

  return (
    <section ref={sectionRef} className="py-20 bg-[#f6f6f6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="videos-header flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <h2 className="section-title mb-4">Video Highlights</h2>
            <p className="text-gray-600 max-w-lg">
              Relive the most memorable moments from the tournament with our exclusive 
              video collection.
            </p>
          </div>
          <Link
            to="#"
            className="group inline-flex items-center gap-2 text-tennis-dark font-oswald uppercase text-sm tracking-wider hover:text-tennis-accent transition-colors"
          >
            <Play className="w-4 h-4" />
            View All Videos
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        {/* Videos Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Featured Video */}
          {featuredVideo && (
            <div className="featured-video lg:col-span-2 lg:row-span-2 group relative overflow-hidden rounded-2xl bg-white shadow-lg">
              <div className="relative h-full min-h-[400px]">
                <img
                  src={featuredVideo.thumbnail}
                  alt={featuredVideo.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-tennis-dark via-transparent to-transparent" />
                
                {/* Play Button */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <button className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center transition-all duration-300 group-hover:bg-tennis-gold group-hover:scale-110">
                    <Play className="w-8 h-8 text-white fill-white ml-1" />
                  </button>
                </div>

                {/* Duration Badge */}
                <div className="absolute top-4 right-4 px-3 py-1 bg-tennis-dark/80 text-white text-sm font-oswald rounded">
                  {featuredVideo.duration}
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <h3 className="font-oswald text-2xl text-white uppercase mb-3 group-hover:text-tennis-gold transition-colors">
                    {featuredVideo.title}
                  </h3>
                  <div className="flex items-center gap-4 text-white/70 text-sm">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {featuredVideo.views} views
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Small Videos */}
          <div className="flex flex-col gap-6">
            {smallVideos.map((video) => (
              <div
                key={video.id}
                className="small-video group relative overflow-hidden rounded-xl bg-white shadow-md flex-1"
              >
                <div className="relative h-full min-h-[180px]">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-tennis-dark via-tennis-dark/40 to-transparent" />
                  
                  {/* Play Button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <button className="w-14 h-14 bg-tennis-gold rounded-full flex items-center justify-center transition-transform duration-300 hover:scale-110">
                      <Play className="w-6 h-6 text-tennis-dark fill-tennis-dark ml-0.5" />
                    </button>
                  </div>

                  {/* Duration Badge */}
                  <div className="absolute top-3 right-3 px-2 py-0.5 bg-tennis-dark/80 text-white text-xs font-oswald rounded flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {video.duration}
                  </div>

                  {/* Content */}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="font-oswald text-lg text-white uppercase line-clamp-2 group-hover:text-tennis-gold transition-colors">
                      {video.title}
                    </h3>
                    <div className="flex items-center gap-1 text-white/60 text-xs mt-1">
                      <Eye className="w-3 h-3" />
                      {video.views} views
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
