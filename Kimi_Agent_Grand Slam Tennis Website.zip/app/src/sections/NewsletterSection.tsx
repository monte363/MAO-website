import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Star, Ticket, Video, Mail } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const benefits = [
  { icon: Video, text: 'Exclusive match highlights' },
  { icon: Ticket, text: 'Early access to tickets' },
  { icon: Star, text: 'Behind-the-scenes content' },
  { icon: Mail, text: 'Player interviews and insights' },
];

export default function NewsletterSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Left content animation
      gsap.fromTo(
        '.newsletter-left',
        { x: -50, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.7,
          delay: 0.3,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Benefits animation
      gsap.fromTo(
        '.benefit-item',
        { x: -30, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          delay: 0.5,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );

      // Form card animation
      gsap.fromTo(
        '.newsletter-form',
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          delay: 0.4,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      setIsSubmitted(true);
      setEmail('');
    }, 1500);
  };

  return (
    <section ref={sectionRef} className="py-20 bg-tennis-dark relative overflow-hidden">
      {/* Diagonal Background */}
      <div 
        className="absolute inset-0 bg-tennis-accent/10"
        style={{
          clipPath: 'polygon(0 0, 55% 0, 45% 100%, 0 100%)',
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="newsletter-left">
            <h2 className="font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
              Join The Grand Slam
              <span className="block text-tennis-gold">Newsletter</span>
            </h2>
            <p className="text-white/70 text-lg mb-8">
              Get exclusive updates delivered straight to your inbox. Be the first 
              to know about tournament news, special offers, and behind-the-scenes content.
            </p>

            {/* Benefits List */}
            <ul className="space-y-4">
              {benefits.map((benefit, index) => (
                <li
                  key={index}
                  className="benefit-item flex items-center gap-3 text-white/80"
                >
                  <div className="w-8 h-8 bg-tennis-gold/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-4 h-4 text-tennis-gold" />
                  </div>
                  <span>{benefit.text}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Right Content - Form */}
          <div className="newsletter-form">
            <div className="bg-white rounded-2xl p-8 shadow-2xl">
              {!isSubmitted ? (
                <>
                  <h3 className="font-oswald text-2xl text-tennis-dark uppercase mb-2">
                    Subscribe Now
                  </h3>
                  <p className="text-gray-600 text-sm mb-6">
                    Join 50,000+ tennis fans who receive our weekly updates.
                  </p>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"
                        className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-tennis-accent focus:border-transparent transition-all duration-300 outline-none"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full bg-tennis-dark text-white py-4 font-oswald uppercase tracking-wider text-sm rounded-lg transition-all duration-300 hover:bg-tennis-accent disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {isLoading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        'Subscribe'
                      )}
                    </button>
                  </form>

                  <p className="mt-4 text-xs text-gray-500 text-center">
                    We respect your privacy. Unsubscribe anytime.
                  </p>
                </>
              ) : (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-oswald text-2xl text-tennis-dark uppercase mb-2">
                    You're Subscribed!
                  </h3>
                  <p className="text-gray-600">
                    Thank you for joining. Check your inbox for a welcome email.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
