import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const newsItems = [
  {
    id: 1,
    title: 'Grand Slam Finals Set for Historic Showdown',
    category: 'Tournament',
    date: 'March 10, 2026',
    image: '/news-1.jpg',
    featured: true,
  },
  {
    id: 2,
    title: 'Underdog Victory Shakes Up Men\'s Singles',
    category: 'Match Report',
    date: 'March 9, 2026',
    image: '/news-2.jpg',
    featured: false,
  },
  {
    id: 3,
    title: 'Doubles Champions Defend Title in Style',
    category: 'Doubles',
    date: 'March 8, 2026',
    image: '/news-3.jpg',
    featured: false,
  },
  {
    id: 4,
    title: 'Rising Star Makes Quarterfinal Debut',
    category: 'Player News',
    date: 'March 7, 2026',
    image: '/news-4.jpg',
    featured: false,
  },
];

export default function NewsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        '.news-title',
        { clipPath: 'inset(0 100% 0 0)', opacity: 0 },
        {
          clipPath: 'inset(0 0% 0 0)',
          opacity: 1,
          duration: 0.8,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Cards stagger animation
      const cards = cardsRef.current?.querySelectorAll('.news-card');
      cards?.forEach((card, index) => {
        gsap.fromTo(
          card,
          { x: 50, opacity: 0 },
          {
            x: 0,
            opacity: 1,
            duration: 0.6,
            delay: 0.2 + index * 0.1,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const featuredNews = newsItems.find((item) => item.featured);
  const regularNews = newsItems.filter((item) => !item.featured);

  return (
    <section ref={sectionRef} className="py-20 bg-[#f6f6f6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <div>
            <h2 className="news-title section-title mb-4">Latest News</h2>
            <p className="text-gray-600 max-w-lg">
              Stay updated with the latest tournament highlights, player interviews, 
              and exclusive behind-the-scenes content.
            </p>
          </div>
          <Link
            to="#"
            className="group inline-flex items-center gap-2 text-tennis-dark font-oswald uppercase text-sm tracking-wider hover:text-tennis-accent transition-colors"
          >
            View All News
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>

        {/* News Grid */}
        <div ref={cardsRef} className="grid lg:grid-cols-2 gap-6">
          {/* Featured News */}
          {featuredNews && (
            <div className="news-card group relative overflow-hidden rounded-2xl bg-white shadow-lg card-hover lg:row-span-2">
              <div className="relative h-full min-h-[400px]">
                <img
                  src={featuredNews.image}
                  alt={featuredNews.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-tennis-dark via-tennis-dark/40 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-8">
                  <span className="inline-block px-3 py-1 bg-tennis-gold text-tennis-dark text-xs font-oswald uppercase tracking-wider rounded mb-4">
                    {featuredNews.category}
                  </span>
                  <h3 className="font-oswald text-2xl md:text-3xl text-white uppercase mb-3 group-hover:text-tennis-gold transition-colors">
                    {featuredNews.title}
                  </h3>
                  <div className="flex items-center gap-2 text-white/70 text-sm">
                    <Calendar className="w-4 h-4" />
                    {featuredNews.date}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Regular News */}
          <div className="grid gap-6">
            {regularNews.map((news) => (
              <div
                key={news.id}
                className="news-card group flex gap-4 bg-white rounded-xl overflow-hidden shadow-md card-hover"
              >
                <div className="relative w-32 md:w-48 flex-shrink-0 overflow-hidden">
                  <img
                    src={news.image}
                    alt={news.title}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="flex flex-col justify-center py-4 pr-4">
                  <span className="inline-block w-fit px-2 py-0.5 bg-tennis-light text-tennis-accent text-xs font-oswald uppercase tracking-wider rounded mb-2">
                    {news.category}
                  </span>
                  <h3 className="font-oswald text-lg text-tennis-dark uppercase mb-2 line-clamp-2 group-hover:text-tennis-accent transition-colors">
                    {news.title}
                  </h3>
                  <div className="flex items-center gap-2 text-gray-500 text-sm">
                    <Calendar className="w-4 h-4" />
                    {news.date}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
