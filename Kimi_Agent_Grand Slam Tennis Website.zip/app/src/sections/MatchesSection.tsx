import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Link } from 'react-router-dom';
import { Circle, MapPin, Clock } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const matches = [
  {
    id: 1,
    type: 'Men\'s Singles Final',
    court: 'Court Central',
    status: 'live',
    player1: { name: 'Alexander Kovac', country: 'SRB', image: '/player-2.jpg' },
    player2: { name: 'Marcus Chen', country: 'USA', image: '/player-6.jpg' },
    score: '6-4, 3-6, 6-4',
    image: '/match-bg-1.jpg',
  },
  {
    id: 2,
    type: 'Women\'s Doubles Semifinal',
    court: 'Court 1',
    status: 'upcoming',
    player1: { name: 'Emma Wilson', country: 'GBR', image: '/player-1.jpg' },
    player2: { name: 'Sofia Martinez', country: 'ESP', image: '/player-3.jpg' },
    time: '14:00',
    image: '/match-bg-2.jpg',
  },
  {
    id: 3,
    type: 'Mixed Doubles Quarterfinal',
    court: 'Court 2',
    status: 'completed',
    player1: { name: 'James Park', country: 'KOR', image: '/player-4.jpg' },
    player2: { name: 'Yuki Tanaka', country: 'JPN', image: '/player-5.jpg' },
    score: '6-3, 7-5',
    image: '/match-bg-3.jpg',
  },
];

const filters = ['All', 'Singles', 'Doubles', 'Finals'];

export default function MatchesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const [activeFilter, setActiveFilter] = useState('All');

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        '.matches-title',
        { y: 50, opacity: 0, scale: 0.9 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.6,
          ease: 'back.out(1.7)',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.match-card');
      cards?.forEach((card, index) => {
        gsap.fromTo(
          card,
          { rotateZ: -3 + index, x: 20 * index, opacity: 0 },
          {
            rotateZ: 0,
            x: 0,
            opacity: 1,
            duration: 0.7,
            delay: 0.2 + index * 0.15,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'live':
        return (
          <div className="flex items-center gap-2">
            <Circle className="w-3 h-3 fill-red-500 text-red-500 animate-live-pulse" />
            <span className="text-red-400 font-oswald text-sm uppercase">Live</span>
          </div>
        );
      case 'upcoming':
        return (
          <div className="flex items-center gap-2 text-tennis-gold">
            <Clock className="w-4 h-4" />
            <span className="font-oswald text-sm uppercase">Upcoming</span>
          </div>
        );
      case 'completed':
        return (
          <span className="text-white/60 font-oswald text-sm uppercase">Completed</span>
        );
      default:
        return null;
    }
  };

  return (
    <section ref={sectionRef} className="py-20 bg-tennis-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="matches-title font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
            Featured Matches
          </h2>
          <p className="text-white/70 max-w-lg mx-auto">
            Watch the most exciting clashes as world-class players battle for championship glory.
          </p>
        </div>

        {/* Filters */}
        <div className="flex justify-center gap-2 mb-12">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-2 font-oswald text-sm uppercase tracking-wider rounded transition-all duration-300 ${
                activeFilter === filter
                  ? 'bg-tennis-gold text-tennis-dark'
                  : 'bg-white/10 text-white/70 hover:bg-white/20 hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Match Cards */}
        <div ref={cardsRef} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {matches.map((match) => (
            <div
              key={match.id}
              className="match-card group relative overflow-hidden rounded-2xl bg-white/5 border border-white/10 transition-all duration-500 hover:border-tennis-gold/50 hover:shadow-glow-lg"
            >
              {/* Background Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={match.image}
                  alt={match.type}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-tennis-dark via-tennis-dark/60 to-transparent" />
                
                {/* Status Badge */}
                <div className="absolute top-4 left-4">
                  {getStatusBadge(match.status)}
                </div>

                {/* Court Info */}
                <div className="absolute top-4 right-4 flex items-center gap-1 text-white/70 text-sm">
                  <MapPin className="w-4 h-4" />
                  {match.court}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="font-oswald text-lg text-white uppercase mb-4">
                  {match.type}
                </h3>

                {/* Players */}
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={match.player1.image}
                      alt={match.player1.name}
                      className="w-10 h-10 rounded-full object-cover border-2 border-tennis-gold"
                    />
                    <div className="flex-1">
                      <p className="text-white font-medium text-sm">{match.player1.name}</p>
                      <p className="text-white/50 text-xs">{match.player1.country}</p>
                    </div>
                    {match.score && (
                      <span className="font-oswald text-xl text-tennis-gold">
                        {match.score.split(',')[0].split('-')[0]}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-center">
                    <span className="text-white/30 font-oswald text-xs uppercase">VS</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <img
                      src={match.player2.image}
                      alt={match.player2.name}
                      className="w-10 h-10 rounded-full object-cover border-2 border-white/30"
                    />
                    <div className="flex-1">
                      <p className="text-white font-medium text-sm">{match.player2.name}</p>
                      <p className="text-white/50 text-xs">{match.player2.country}</p>
                    </div>
                    {match.score && (
                      <span className="font-oswald text-xl text-white">
                        {match.score.split(',')[0].split('-')[1]}
                      </span>
                    )}
                  </div>
                </div>

                {/* Score or Time */}
                {match.score && (
                  <div className="mt-4 pt-4 border-t border-white/10 text-center">
                    <span className="text-white/60 text-sm">{match.score}</span>
                  </div>
                )}
                {match.time && (
                  <div className="mt-4 pt-4 border-t border-white/10 text-center">
                    <span className="text-tennis-gold font-oswald text-lg">{match.time}</span>
                  </div>
                )}

                {/* CTA */}
                <Link
                  to="/scores"
                  className="mt-4 block w-full text-center py-3 bg-white/10 text-white font-oswald uppercase text-sm tracking-wider rounded transition-all duration-300 hover:bg-tennis-gold hover:text-tennis-dark"
                >
                  {match.status === 'live' ? 'Watch Live' : match.status === 'upcoming' ? 'Set Reminder' : 'View Details'}
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
