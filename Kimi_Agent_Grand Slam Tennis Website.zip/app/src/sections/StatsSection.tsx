import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Trophy, Users, Calendar, MapPin } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { id: 1, value: 150, suffix: '', label: 'Matches Played', icon: Trophy },
  { id: 2, value: 28, suffix: '', label: 'Years of Excellence', icon: Calendar },
  { id: 3, value: 45, suffix: '', label: 'World-Class Players', icon: Users },
  { id: 4, value: 8, suffix: '', label: 'Championship Courts', icon: MapPin },
];

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const counterRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            let start = 0;
            const end = value;
            const duration = 2000;
            const increment = end / (duration / 16);
            
            const timer = setInterval(() => {
              start += increment;
              if (start >= end) {
                setCount(end);
                clearInterval(timer);
              } else {
                setCount(Math.floor(start));
              }
            }, 16);

            observer.disconnect();
          }
        });
      },
      { threshold: 0.5 }
    );

    if (counterRef.current) {
      observer.observe(counterRef.current);
    }

    return () => observer.disconnect();
  }, [value]);

  return (
    <span ref={counterRef} className="font-oswald text-5xl md:text-6xl font-bold text-tennis-gold">
      {count}{suffix}
    </span>
  );
}

export default function StatsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title animation
      gsap.fromTo(
        '.stats-title',
        { opacity: 0, scale: 0.9 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.6,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Trophy animation
      gsap.fromTo(
        '.stats-trophy',
        { rotateY: 180, scale: 0, opacity: 0 },
        {
          rotateY: 0,
          scale: 1,
          opacity: 1,
          duration: 0.8,
          delay: 0.2,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Stats animation
      const statItems = sectionRef.current?.querySelectorAll('.stat-item');
      statItems?.forEach((item, index) => {
        gsap.fromTo(
          item,
          { y: 30, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: 0.7,
            delay: 0.4 + index * 0.15,
            ease: 'expo.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
            },
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 bg-[#f6f6f6] relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-tennis-gold/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="stats-title section-title mb-4">Statistics</h2>
          <p className="text-gray-600 max-w-lg mx-auto">
            The numbers that define our legacy of excellence in professional tennis.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat) => (
            <div
              key={stat.id}
              className="stat-item group text-center p-8 bg-white rounded-2xl shadow-lg transition-all duration-500 hover:-translate-y-2 hover:shadow-xl"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 mb-6 bg-tennis-light rounded-full transition-all duration-300 group-hover:bg-tennis-dark group-hover:scale-110">
                <stat.icon className="w-8 h-8 text-tennis-accent transition-colors duration-300 group-hover:text-tennis-gold" />
              </div>
              <AnimatedCounter value={stat.value} suffix={stat.suffix} />
              <p className="mt-3 text-gray-600 font-medium">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Center Trophy */}
        <div className="stats-trophy flex justify-center mt-16">
          <div className="relative">
            <div className="w-32 h-32 bg-tennis-gold/20 rounded-full flex items-center justify-center animate-pulse-glow">
              <Trophy className="w-16 h-16 text-tennis-gold" />
            </div>
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap">
              <span className="font-oswald text-sm uppercase tracking-wider text-tennis-dark/60">
                Championship Trophy
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
