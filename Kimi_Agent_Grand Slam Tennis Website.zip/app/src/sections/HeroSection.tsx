import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { Link } from 'react-router-dom';
import { ArrowRight, Circle } from 'lucide-react';

export default function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Background animation
      gsap.fromTo(
        '.hero-bg',
        { scale: 1.1, opacity: 0 },
        { scale: 1, opacity: 1, duration: 1.2, ease: 'expo.out' }
      );

      // Title animation
      gsap.fromTo(
        titleRef.current,
        { y: 50, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, delay: 0.5, ease: 'expo.out' }
      );

      // Subtitle animation
      gsap.fromTo(
        subtitleRef.current,
        { y: 30, opacity: 0, filter: 'blur(10px)' },
        { y: 0, opacity: 1, filter: 'blur(0px)', duration: 0.7, delay: 0.8, ease: 'power2.out' }
      );

      // CTA animation
      gsap.fromTo(
        ctaRef.current,
        { scale: 0.8, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.5, delay: 1.1, ease: 'back.out(1.7)' }
      );

      // Match card animation
      gsap.fromTo(
        cardRef.current,
        { x: 100, opacity: 0, rotateY: 15 },
        { x: 0, opacity: 1, rotateY: 0, duration: 1, delay: 0.8, ease: 'expo.out' }
      );

      // Floating animation for card
      gsap.to(cardRef.current, {
        y: -10,
        duration: 4,
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Background Image */}
      <div className="hero-bg absolute inset-0">
        <img
          src="/hero-bg.jpg"
          alt="Tennis Championship"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-tennis-dark/90 via-tennis-dark/60 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 w-full">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full">
              <span className="w-2 h-2 bg-tennis-gold rounded-full animate-pulse" />
              <span className="text-tennis-gold font-oswald text-sm uppercase tracking-wider">
                Grand Slam 2026
              </span>
            </div>

            <h1
              ref={titleRef}
              className="font-oswald text-5xl md:text-6xl lg:text-7xl font-bold text-white uppercase leading-tight"
            >
              Championship
              <span className="block text-tennis-gold">Excellence</span>
            </h1>

            <p
              ref={subtitleRef}
              className="text-lg md:text-xl text-white/80 max-w-lg leading-relaxed"
            >
              Experience the pinnacle of tennis excellence. Witness world-class 
              athletes compete for glory at the most prestigious tournament in 
              professional tennis.
            </p>

            <div ref={ctaRef} className="flex flex-wrap gap-4">
              <Link
                to="/scores"
                className="group inline-flex items-center gap-3 bg-tennis-gold text-tennis-dark px-8 py-4 font-oswald uppercase tracking-wider text-sm font-semibold rounded transition-all duration-300 hover:bg-white hover:scale-[1.02]"
              >
                Explore Tournament
                <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
              <Link
                to="/players"
                className="inline-flex items-center gap-3 border-2 border-white/30 text-white px-8 py-4 font-oswald uppercase tracking-wider text-sm rounded transition-all duration-300 hover:bg-white/10 hover:border-white/50"
              >
                Meet The Players
              </Link>
            </div>
          </div>

          {/* Right Content - Featured Match Card */}
          <div className="hidden lg:block">
            <div
              ref={cardRef}
              className="relative bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 shadow-2xl perspective-1200"
            >
              {/* Live Indicator */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Circle className="w-3 h-3 fill-red-500 text-red-500 animate-live-pulse" />
                  <span className="text-red-400 font-oswald text-sm uppercase tracking-wider">
                    Live Now
                  </span>
                </div>
                <span className="text-white/60 text-sm">Court Central</span>
              </div>

              {/* Match Title */}
              <h3 className="font-oswald text-xl text-white uppercase mb-6">
                Men's Singles Final
              </h3>

              {/* Players */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <img
                      src="/player-2.jpg"
                      alt="Player 1"
                      className="w-12 h-12 rounded-full object-cover border-2 border-tennis-gold"
                    />
                    <div>
                      <p className="text-white font-semibold">Alexander Kovac</p>
                      <p className="text-white/60 text-sm">Serbia</p>
                    </div>
                  </div>
                  <span className="font-oswald text-3xl text-tennis-gold">6</span>
                </div>

                <div className="flex items-center justify-center">
                  <span className="text-white/40 font-oswald text-sm uppercase">VS</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <img
                      src="/player-6.jpg"
                      alt="Player 2"
                      className="w-12 h-12 rounded-full object-cover border-2 border-white/30"
                    />
                    <div>
                      <p className="text-white font-semibold">Marcus Chen</p>
                      <p className="text-white/60 text-sm">USA</p>
                    </div>
                  </div>
                  <span className="font-oswald text-3xl text-white">4</span>
                </div>
              </div>

              {/* Set Scores */}
              <div className="mt-6 pt-6 border-t border-white/20">
                <div className="flex justify-between text-sm">
                  <span className="text-white/60">Set 1: 6-4</span>
                  <span className="text-white/60">Set 2: 3-6</span>
                  <span className="text-tennis-gold">Set 3: 6-4</span>
                </div>
              </div>

              {/* CTA */}
              <Link
                to="/scores"
                className="mt-6 block w-full text-center bg-tennis-gold/20 text-tennis-gold py-3 rounded font-oswald uppercase text-sm tracking-wider transition-all duration-300 hover:bg-tennis-gold hover:text-tennis-dark"
              >
                Watch Live
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#f6f6f6] to-transparent" />
    </section>
  );
}
