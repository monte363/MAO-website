import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { TrendingUp, TrendingDown, Minus, Search } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const rankingsData = [
  { rank: 1, name: 'Alexander Kovac', country: 'SRB', points: 9850, change: 0, image: '/player-2.jpg' },
  { rank: 2, name: 'Marcus Chen', country: 'USA', points: 8720, change: 1, image: '/player-6.jpg' },
  { rank: 3, name: 'Emma Wilson', country: 'GBR', points: 8450, change: -1, image: '/player-1.jpg' },
  { rank: 4, name: 'Sofia Martinez', country: 'ESP', points: 7980, change: 2, image: '/player-3.jpg' },
  { rank: 5, name: 'James Park', country: 'USA', points: 7650, change: 0, image: '/player-4.jpg' },
  { rank: 6, name: 'Yuki Tanaka', country: 'JPN', points: 7420, change: 3, image: '/player-5.jpg' },
  { rank: 7, name: 'Lucas Silva', country: 'BRA', points: 6980, change: -2, image: '/player-2.jpg' },
  { rank: 8, name: 'Ana Rodriguez', country: 'ARG', points: 6750, change: 1, image: '/player-1.jpg' },
  { rank: 9, name: 'David Kim', country: 'KOR', points: 6520, change: -1, image: '/player-6.jpg' },
  { rank: 10, name: 'Maria Garcia', country: 'MEX', points: 6280, change: 0, image: '/player-3.jpg' },
];

const categories = ['ATP Singles', 'WTA Singles', 'ATP Doubles', 'WTA Doubles'];

export default function Rankings() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeCategory, setActiveCategory] = useState('ATP Singles');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.rankings-row',
        { x: -20, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.05,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getChangeIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="w-4 h-4 text-green-500" />;
    if (change < 0) return <TrendingDown className="w-4 h-4 text-red-500" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  const filteredRankings = rankingsData.filter(player =>
    player.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="pt-20 min-h-screen bg-[#f6f6f6]">
      {/* Header */}
      <div className="bg-tennis-dark py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
            Player Rankings
          </h1>
          <p className="text-white/70 max-w-lg">
            Current standings of the world's top tennis players. Updated weekly based on tournament performance.
          </p>
        </div>
      </div>

      {/* Content */}
      <div ref={sectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Filters */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 font-oswald text-sm uppercase tracking-wider rounded transition-all duration-300 ${
                  activeCategory === category
                    ? 'bg-tennis-dark text-white'
                    : 'bg-white text-tennis-dark hover:bg-tennis-light'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search players..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full md:w-64 border border-gray-200 rounded-lg focus:ring-2 focus:ring-tennis-accent focus:border-transparent outline-none"
            />
          </div>
        </div>

        {/* Rankings Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Table Header */}
          <div className="grid grid-cols-12 gap-4 p-4 bg-tennis-dark text-white font-oswald uppercase text-sm tracking-wider">
            <div className="col-span-1 text-center">Rank</div>
            <div className="col-span-5 md:col-span-4">Player</div>
            <div className="col-span-3 md:col-span-2 text-center">Country</div>
            <div className="col-span-2 md:col-span-3 text-center">Points</div>
            <div className="col-span-1 text-center">+/-</div>
          </div>

          {/* Table Body */}
          <div className="divide-y divide-gray-100">
            {filteredRankings.map((player) => (
              <div
                key={player.rank}
                className="rankings-row grid grid-cols-12 gap-4 p-4 items-center hover:bg-tennis-light/50 transition-colors"
              >
                <div className="col-span-1 text-center">
                  <span className={`font-oswald text-xl font-bold ${
                    player.rank <= 3 ? 'text-tennis-gold' : 'text-tennis-dark'
                  }`}>
                    {player.rank}
                  </span>
                </div>
                <div className="col-span-5 md:col-span-4 flex items-center gap-3">
                  <img
                    src={player.image}
                    alt={player.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <span className="font-medium text-tennis-dark truncate">{player.name}</span>
                </div>
                <div className="col-span-3 md:col-span-2 text-center text-gray-600">
                  {player.country}
                </div>
                <div className="col-span-2 md:col-span-3 text-center font-oswald text-lg text-tennis-dark">
                  {player.points.toLocaleString()}
                </div>
                <div className="col-span-1 flex justify-center">
                  {getChangeIcon(player.change)}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Last Updated */}
        <div className="mt-6 text-center text-gray-500 text-sm">
          Last updated: March 11, 2026
        </div>
      </div>
    </div>
  );
}
