import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Trophy, Star, Award, Crown, Gem, Shield } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const sponsors = [
  {
    tier: 'Platinum',
    icon: Crown,
    color: 'from-gray-300 to-gray-500',
    sponsors: [
      { name: 'TennisPro', description: 'Official Equipment Partner' },
      { name: 'GlobalBank', description: 'Official Banking Partner' },
      { name: 'SportsMax', description: 'Official Broadcast Partner' },
    ],
  },
  {
    tier: 'Gold',
    icon: Trophy,
    color: 'from-yellow-400 to-yellow-600',
    sponsors: [
      { name: 'EliteWatches', description: 'Official Timekeeper' },
      { name: 'PremiumAuto', description: 'Official Vehicle Partner' },
      { name: 'LuxuryHotels', description: 'Official Hospitality Partner' },
      { name: 'TechGiant', description: 'Official Technology Partner' },
    ],
  },
  {
    tier: 'Silver',
    icon: Star,
    color: 'from-gray-400 to-gray-600',
    sponsors: [
      { name: 'FitLife', description: 'Official Fitness Partner' },
      { name: 'AquaPure', description: 'Official Water Partner' },
      { name: 'EnergyDrink', description: 'Official Energy Partner' },
      { name: 'AirLines', description: 'Official Airline Partner' },
      { name: 'FashionBrand', description: 'Official Fashion Partner' },
    ],
  },
  {
    tier: 'Bronze',
    icon: Award,
    color: 'from-orange-400 to-orange-600',
    sponsors: [
      { name: 'LocalBank', description: 'Regional Partner' },
      { name: 'SportsGear', description: 'Equipment Partner' },
      { name: 'HealthFirst', description: 'Wellness Partner' },
      { name: 'MediaGroup', description: 'Media Partner' },
      { name: 'FoodCorp', description: 'Catering Partner' },
      { name: 'RetailChain', description: 'Retail Partner' },
    ],
  },
];

const sponsorPackages = [
  {
    name: 'Platinum',
    price: '$500,000',
    icon: Crown,
    benefits: [
      'Logo on all tournament materials',
      'VIP hospitality for 20 guests',
      'Player meet & greet opportunities',
      'Premium court-side seating',
      'Exclusive branding rights',
      'Social media promotion',
    ],
  },
  {
    name: 'Gold',
    price: '$250,000',
    icon: Trophy,
    benefits: [
      'Logo on select tournament materials',
      'VIP hospitality for 10 guests',
      'Premium seating area access',
      'Brand visibility on digital platforms',
      'Tournament merchandise inclusion',
    ],
  },
  {
    name: 'Silver',
    price: '$100,000',
    icon: Star,
    benefits: [
      'Logo on website and programs',
      'VIP hospitality for 5 guests',
      'Reserved seating section',
      'Social media mentions',
      'Networking opportunities',
    ],
  },
];

export default function Sponsors() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.sponsor-tier',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.15,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      gsap.fromTo(
        '.package-card',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: '.packages-section',
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <div className="pt-20 min-h-screen bg-[#f6f6f6]">
      {/* Header */}
      <div className="bg-tennis-dark py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
            Our Sponsors
          </h1>
          <p className="text-white/70 max-w-lg">
            We are proud to partner with world-class brands that share our passion for excellence in tennis.
          </p>
        </div>
      </div>

      {/* Content */}
      <div ref={sectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Sponsor Tiers */}
        <div className="space-y-12 mb-20">
          {sponsors.map((tier) => (
            <div key={tier.tier} className="sponsor-tier">
              <div className="flex items-center gap-3 mb-6">
                <div className={`p-3 rounded-lg bg-gradient-to-br ${tier.color}`}>
                  <tier.icon className="w-6 h-6 text-white" />
                </div>
                <h2 className="font-oswald text-2xl text-tennis-dark uppercase">
                  {tier.tier} Partners
                </h2>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tier.sponsors.map((sponsor, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${tier.color} flex items-center justify-center`}>
                        <Shield className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-oswald text-lg text-tennis-dark">{sponsor.name}</h3>
                        <p className="text-sm text-gray-500">{sponsor.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Sponsor Packages */}
        <div className="packages-section">
          <div className="text-center mb-12">
            <h2 className="section-title mb-4">Become a Sponsor</h2>
            <p className="text-gray-600 max-w-lg mx-auto">
              Join our family of sponsors and gain exclusive access to one of the world's most prestigious tennis tournaments.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {sponsorPackages.map((pkg) => (
              <div
                key={pkg.name}
                className="package-card bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
              >
                <div className="p-6 bg-tennis-dark text-white">
                  <div className="flex items-center justify-between mb-4">
                    <pkg.icon className="w-8 h-8 text-tennis-gold" />
                    <span className="font-oswald text-2xl">{pkg.price}</span>
                  </div>
                  <h3 className="font-oswald text-xl uppercase">{pkg.name}</h3>
                </div>
                <div className="p-6">
                  <ul className="space-y-3">
                    {pkg.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                        <Gem className="w-4 h-4 text-tennis-gold flex-shrink-0 mt-0.5" />
                        {benefit}
                      </li>
                    ))}
                  </ul>
                  <button className="w-full mt-6 py-3 bg-tennis-dark text-white font-oswald uppercase tracking-wider rounded-lg transition-all duration-300 hover:bg-tennis-accent">
                    Inquire Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
