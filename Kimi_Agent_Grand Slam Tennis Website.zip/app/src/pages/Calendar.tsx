import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon, MapPin, Trophy } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const tournamentEvents = [
  { date: '2026-03-01', title: 'Qualifying Round Begins', type: 'qualifying', court: 'All Courts' },
  { date: '2026-03-05', title: 'Main Draw Announcement', type: 'announcement', court: '-' },
  { date: '2026-03-08', title: 'First Round - Day 1', type: 'match', court: 'All Courts' },
  { date: '2026-03-09', title: 'First Round - Day 2', type: 'match', court: 'All Courts' },
  { date: '2026-03-10', title: 'Second Round Begins', type: 'match', court: 'All Courts' },
  { date: '2026-03-12', title: 'Third Round', type: 'match', court: 'All Courts' },
  { date: '2026-03-14', title: 'Round of 16', type: 'match', court: 'Center Court' },
  { date: '2026-03-16', title: 'Quarterfinals', type: 'match', court: 'Center Court' },
  { date: '2026-03-18', title: 'Semifinals', type: 'match', court: 'Center Court' },
  { date: '2026-03-20', title: 'Women\'s Singles Final', type: 'final', court: 'Center Court' },
  { date: '2026-03-21', title: 'Men\'s Singles Final', type: 'final', court: 'Center Court' },
  { date: '2026-03-22', title: 'Doubles Finals', type: 'final', court: 'Center Court' },
];

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export default function Calendar() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [currentDate, setCurrentDate] = useState(new Date(2026, 2, 1)); // March 2026

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.calendar-item',
        { x: -20, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.05,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const getEventsForDate = (day: number) => {
    const dateStr = `2026-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return tournamentEvents.filter(event => event.date === dateStr);
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case 'final':
        return 'bg-tennis-gold text-tennis-dark';
      case 'qualifying':
        return 'bg-blue-100 text-blue-700';
      case 'announcement':
        return 'bg-purple-100 text-purple-700';
      default:
        return 'bg-tennis-light text-tennis-accent';
    }
  };

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: firstDay }, (_, i) => i);

  return (
    <div className="pt-20 min-h-screen bg-[#f6f6f6]">
      {/* Header */}
      <div className="bg-tennis-dark py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
            Tournament Calendar
          </h1>
          <p className="text-white/70 max-w-lg">
            View the complete schedule of matches, finals, and special events throughout the tournament.
          </p>
        </div>
      </div>

      {/* Content */}
      <div ref={sectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Calendar */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              {/* Calendar Header */}
              <div className="flex items-center justify-between p-6 bg-tennis-dark text-white">
                <button
                  onClick={() => navigateMonth('prev')}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <h2 className="font-oswald text-xl uppercase">
                  {months[currentDate.getMonth()]} {currentDate.getFullYear()}
                </h2>
                <button
                  onClick={() => navigateMonth('next')}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Days Header */}
              <div className="grid grid-cols-7 gap-px bg-gray-200">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="bg-gray-50 p-3 text-center font-oswald text-sm text-gray-600">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-px bg-gray-200">
                {emptyDays.map((_, i) => (
                  <div key={`empty-${i}`} className="bg-white min-h-[100px]" />
                ))}
                {days.map(day => {
                  const events = getEventsForDate(day);
                  const isToday = day === 11 && currentDate.getMonth() === 2; // March 11

                  return (
                    <div
                      key={day}
                      className={`calendar-item bg-white min-h-[100px] p-2 transition-colors hover:bg-tennis-light/30 ${
                        isToday ? 'bg-tennis-light/50' : ''
                      }`}
                    >
                      <span className={`font-oswald text-sm ${isToday ? 'text-tennis-accent font-bold' : 'text-gray-700'}`}>
                        {day}
                      </span>
                      {events.map((event, idx) => (
                        <div
                          key={idx}
                          className={`mt-1 px-2 py-1 rounded text-xs font-medium truncate ${getEventTypeColor(event.type)}`}
                        >
                          {event.title}
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Events List */}
          <div>
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="font-oswald text-xl text-tennis-dark uppercase mb-6 flex items-center gap-2">
                <CalendarIcon className="w-5 h-5" />
                Upcoming Events
              </h3>
              <div className="space-y-4">
                {tournamentEvents.slice(0, 6).map((event, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-tennis-light/50 transition-colors"
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${getEventTypeColor(event.type)}`}>
                      {event.type === 'final' ? (
                        <Trophy className="w-5 h-5" />
                      ) : (
                        <CalendarIcon className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-tennis-dark text-sm">{event.title}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </p>
                      {event.court !== '-' && (
                        <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3" />
                          {event.court}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Legend */}
            <div className="bg-white rounded-2xl shadow-lg p-6 mt-6">
              <h3 className="font-oswald text-lg text-tennis-dark uppercase mb-4">Event Types</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-tennis-gold" />
                  <span className="text-sm text-gray-600">Finals</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-tennis-light" />
                  <span className="text-sm text-gray-600">Regular Matches</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-blue-100" />
                  <span className="text-sm text-gray-600">Qualifying</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-purple-100" />
                  <span className="text-sm text-gray-600">Announcements</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
