import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import HeroSection from '../sections/HeroSection';
import NewsSection from '../sections/NewsSection';
import MatchesSection from '../sections/MatchesSection';
import VideosSection from '../sections/VideosSection';
import PlayersSection from '../sections/PlayersSection';
import StatsSection from '../sections/StatsSection';
import NewsletterSection from '../sections/NewsletterSection';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const sectionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const sections = sectionsRef.current?.querySelectorAll('.animate-section');
    
    sections?.forEach((section) => {
      gsap.fromTo(
        section,
        { opacity: 0.9, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <div ref={sectionsRef}>
      <HeroSection />
      <div className="animate-section">
        <NewsSection />
      </div>
      <div className="animate-section">
        <MatchesSection />
      </div>
      <div className="animate-section">
        <VideosSection />
      </div>
      <div className="animate-section">
        <PlayersSection />
      </div>
      <div className="animate-section">
        <StatsSection />
      </div>
      <div className="animate-section">
        <NewsletterSection />
      </div>
    </div>
  );
}
