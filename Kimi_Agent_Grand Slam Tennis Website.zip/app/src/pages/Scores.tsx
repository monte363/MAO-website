import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Circle, MapPin, Clock, Calendar, ChevronRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const matchesData = [
  {
    id: 1,
    round: 'Men\'s Singles Final',
    court: 'Court Central',
    status: 'live',
    player1: { name: 'Alexander Kovac', country: 'SRB', image: '/player-2.jpg', score: 6 },
    player2: { name: 'Marcus Chen', country: 'USA', image: '/player-6.jpg', score: 4 },
    sets: '6-4, 3-6, 6-4',
    time: '2:34:12',
  },
  {
    id: 2,
    round: 'Women\'s Singles Semifinal',
    court: 'Court 1',
    status: 'live',
    player1: { name: 'Emma Wilson', country: 'GBR', image: '/player-1.jpg', score: 5 },
    player2: { name: 'Sofia Martinez', country: 'ESP', image: '/player-3.jpg', score: 7 },
    sets: '5-7, 6-3, 2-1',
    time: '1:45:33',
  },
  {
    id: 3,
    round: 'Men\'s Doubles Quarterfinal',
    court: 'Court 2',
    status: 'upcoming',
    player1: { name: 'James Park / David Kim', country: 'USA/KOR', image: '/player-4.jpg', score: null },
    player2: { name: 'Lucas Silva / Ana Rodriguez', country: 'BRA/ARG', image: '/player-2.jpg', score: null },
    time: '15:00',
  },
  {
    id: 4,
    round: 'Women\'s Doubles Semifinal',
    court: 'Court 3',
    status: 'completed',
    player1: { name: 'Yuki Tanaka / Maria Garcia', country: 'JPN/MEX', image: '/player-5.jpg', score: 6 },
    player2: { name: 'Emma Wilson / Sofia Martinez', country: 'GBR/ESP', image: '/player-1.jpg', score: 3 },
    sets: '6-3, 7-5',
    time: 'Completed',
  },
];

const scheduleData = [
  { time: '10:00', event: 'Gates Open', court: 'All Courts' },
  { time: '11:00', event: 'Women\'s Singles - Round 1', court: 'Court Central' },
  { time: '13:00', event: 'Men\'s Singles - Round 1', court: 'Court 1' },
  { time: '15:00', event: 'Men\'s Doubles - Quarterfinal', court: 'Court 2' },
  { time: '17:00', event: 'Women\'s Singles - Round 2', court: 'Court Central' },
];

export default function Scores() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeTab, setActiveTab] = useState<'live' | 'schedule'>('live');

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.match-card',
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'live':
        return (
          <div className="flex items-center gap-2">
            <Circle className="w-3 h-3 fill-red-500 text-red-500 animate-live-pulse" />
            <span className="text-red-500 font-oswald text-sm uppercase">Live</span>
          </div>
        );
      case 'upcoming':
        return (
          <div className="flex items-center gap-2 text-tennis-gold">
            <Clock className="w-4 h-4" />
            <span className="font-oswald text-sm uppercase">Upcoming</span>
          </div>
        );
      case 'completed':
        return (
          <span className="text-gray-500 font-oswald text-sm uppercase">Completed</span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="pt-20 min-h-screen bg-[#f6f6f6]">
      {/* Header */}
      <div className="bg-tennis-dark py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
            Scores & Schedule
          </h1>
          <p className="text-white/70 max-w-lg">
            Follow live match scores and view the complete tournament schedule.
          </p>
        </div>
      </div>

      {/* Content */}
      <div ref={sectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Tabs */}
        <div className="flex gap-4 mb-8">
          <button
            onClick={() => setActiveTab('live')}
            className={`px-6 py-3 font-oswald uppercase tracking-wider rounded-lg transition-all duration-300 ${
              activeTab === 'live'
                ? 'bg-tennis-dark text-white'
                : 'bg-white text-tennis-dark hover:bg-tennis-light'
            }`}
          >
            Live Matches
          </button>
          <button
            onClick={() => setActiveTab('schedule')}
            className={`px-6 py-3 font-oswald uppercase tracking-wider rounded-lg transition-all duration-300 ${
              activeTab === 'schedule'
                ? 'bg-tennis-dark text-white'
                : 'bg-white text-tennis-dark hover:bg-tennis-light'
            }`}
          >
            Today's Schedule
          </button>
        </div>

        {activeTab === 'live' ? (
          <div className="space-y-6">
            {matchesData.map((match) => (
              <div
                key={match.id}
                className="match-card bg-white rounded-2xl shadow-lg overflow-hidden"
              >
                {/* Header */}
                <div className="flex items-center justify-between px-6 py-4 bg-tennis-dark/5 border-b">
                  <div>
                    <h3 className="font-oswald text-lg text-tennis-dark uppercase">
                      {match.round}
                    </h3>
                    <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {match.court}
                      </span>
                      {match.time && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {match.time}
                        </span>
                      )}
                    </div>
                  </div>
                  {getStatusBadge(match.status)}
                </div>

                {/* Players */}
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    {/* Player 1 */}
                    <div className="flex items-center gap-4 flex-1">
                      <img
                        src={match.player1.image}
                        alt={match.player1.name}
                        className="w-14 h-14 rounded-full object-cover border-2 border-tennis-gold"
                      />
                      <div>
                        <p className="font-semibold text-tennis-dark">{match.player1.name}</p>
                        <p className="text-sm text-gray-500">{match.player1.country}</p>
                      </div>
                    </div>

                    {/* Score */}
                    <div className="flex items-center gap-6 px-8">
                      {match.player1.score !== null && (
                        <span className="font-oswald text-4xl text-tennis-gold">
                          {match.player1.score}
                        </span>
                      )}
                      <span className="text-gray-400 font-oswald">-</span>
                      {match.player2.score !== null && (
                        <span className="font-oswald text-4xl text-tennis-dark">
                          {match.player2.score}
                        </span>
                      )}
                    </div>

                    {/* Player 2 */}
                    <div className="flex items-center gap-4 flex-1 justify-end">
                      <div className="text-right">
                        <p className="font-semibold text-tennis-dark">{match.player2.name}</p>
                        <p className="text-sm text-gray-500">{match.player2.country}</p>
                      </div>
                      <img
                        src={match.player2.image}
                        alt={match.player2.name}
                        className="w-14 h-14 rounded-full object-cover border-2 border-gray-200"
                      />
                    </div>
                  </div>

                  {/* Sets */}
                  {match.sets && (
                    <div className="mt-4 pt-4 border-t text-center">
                      <span className="text-gray-500">Sets: {match.sets}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-6 bg-tennis-dark text-white">
              <div className="flex items-center gap-3">
                <Calendar className="w-6 h-6 text-tennis-gold" />
                <h2 className="font-oswald text-xl uppercase">Today's Schedule</h2>
              </div>
              <p className="text-white/70 mt-1">March 11, 2026</p>
            </div>
            <div className="divide-y divide-gray-100">
              {scheduleData.map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-6 hover:bg-tennis-light/50 transition-colors"
                >
                  <div className="flex items-center gap-6">
                    <span className="font-oswald text-xl text-tennis-gold w-16">
                      {item.time}
                    </span>
                    <div>
                      <p className="font-semibold text-tennis-dark">{item.event}</p>
                      <p className="text-sm text-gray-500 flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {item.court}
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
