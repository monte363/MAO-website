import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ShoppingCart, Search, Star, Plus, Check } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

const products = [
  {
    id: 1,
    name: 'Pro Championship Racket',
    category: 'Equipment',
    price: 299.99,
    rating: 4.9,
    image: '/shop-racket.jpg',
    description: 'Professional-grade tennis racket used by champions. Lightweight carbon fiber construction.',
  },
  {
    id: 2,
    name: 'Grand Slam Apparel Set',
    category: 'Clothing',
    price: 149.99,
    rating: 4.8,
    image: '/shop-apparel.jpg',
    description: 'Premium tennis apparel including polo shirt, shorts, and wristbands.',
  },
  {
    id: 3,
    name: 'Tennis Essentials Kit',
    category: 'Accessories',
    price: 79.99,
    rating: 4.7,
    image: '/shop-accessories.jpg',
    description: 'Complete kit with balls, grips, headbands, and water bottle.',
  },
  {
    id: 4,
    name: 'Championship Trophy Replica',
    category: 'Memorabilia',
    price: 499.99,
    rating: 5.0,
    image: '/shop-trophy.jpg',
    description: 'Official replica of the Grand Slam Championship trophy. Limited edition.',
  },
];

const categories = ['All', 'Equipment', 'Clothing', 'Accessories', 'Memorabilia'];

export default function Shop() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<typeof products[0] | null>(null);
  const [cart, setCart] = useState<number[]>([]);
  const [showAddedMessage, setShowAddedMessage] = useState<number | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.product-card',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const filteredProducts = products.filter(product => {
    const matchesCategory = activeCategory === 'All' || product.category === activeCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (productId: number) => {
    setCart([...cart, productId]);
    setShowAddedMessage(productId);
    setTimeout(() => setShowAddedMessage(null), 2000);
  };

  return (
    <div className="pt-20 min-h-screen bg-[#f6f6f6]">
      {/* Header */}
      <div className="bg-tennis-dark py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
                Official Shop
              </h1>
              <p className="text-white/70 max-w-lg">
                Get official Grand Slam merchandise, equipment, and memorabilia.
              </p>
            </div>
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm px-4 py-3 rounded-lg">
              <ShoppingCart className="w-6 h-6 text-tennis-gold" />
              <span className="text-white font-oswald">{cart.length} items</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div ref={sectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Filters */}
        <div className="flex flex-col md:flex-row md:items-center gap-4 mb-8">
          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 font-oswald text-sm uppercase tracking-wider rounded transition-all duration-300 ${
                  activeCategory === category
                    ? 'bg-tennis-dark text-white'
                    : 'bg-white text-tennis-dark hover:bg-tennis-light'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative flex-1 max-w-md md:ml-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-200 rounded-lg focus:ring-2 focus:ring-tennis-accent focus:border-transparent outline-none"
            />
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="product-card group bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-500 hover:-translate-y-2 hover:shadow-xl"
            >
              {/* Image */}
              <div 
                className="relative h-56 overflow-hidden cursor-pointer"
                onClick={() => setSelectedProduct(product)}
              >
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-3 left-3">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-oswald uppercase text-tennis-dark">
                    {product.category}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-4 h-4 fill-tennis-gold text-tennis-gold" />
                  <span className="text-sm text-gray-600">{product.rating}</span>
                </div>
                <h3 
                  className="font-oswald text-lg text-tennis-dark uppercase mb-2 cursor-pointer hover:text-tennis-accent transition-colors"
                  onClick={() => setSelectedProduct(product)}
                >
                  {product.name}
                </h3>
                <p className="text-gray-500 text-sm mb-4 line-clamp-2">
                  {product.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="font-oswald text-2xl text-tennis-dark">
                    ${product.price}
                  </span>
                  <button
                    onClick={() => addToCart(product.id)}
                    className="p-3 bg-tennis-dark text-white rounded-lg transition-all duration-300 hover:bg-tennis-accent"
                  >
                    {showAddedMessage === product.id ? (
                      <Check className="w-5 h-5" />
                    ) : (
                      <Plus className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Product Detail Dialog */}
      <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent className="max-w-2xl">
          {selectedProduct && (
            <>
              <DialogHeader>
                <DialogTitle className="font-oswald text-2xl uppercase">
                  Product Details
                </DialogTitle>
              </DialogHeader>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <img
                    src={selectedProduct.image}
                    alt={selectedProduct.name}
                    className="w-full h-64 object-cover rounded-xl"
                  />
                </div>
                <div>
                  <span className="inline-block px-3 py-1 bg-tennis-light rounded-full text-xs font-oswald uppercase text-tennis-accent mb-3">
                    {selectedProduct.category}
                  </span>
                  <h2 className="font-oswald text-2xl text-tennis-dark uppercase mb-2">
                    {selectedProduct.name}
                  </h2>
                  <div className="flex items-center gap-1 mb-4">
                    <Star className="w-5 h-5 fill-tennis-gold text-tennis-gold" />
                    <span className="text-lg">{selectedProduct.rating}</span>
                    <span className="text-gray-400">(128 reviews)</span>
                  </div>
                  <p className="text-gray-600 mb-6">{selectedProduct.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="font-oswald text-3xl text-tennis-dark">
                      ${selectedProduct.price}
                    </span>
                    <button
                      onClick={() => {
                        addToCart(selectedProduct.id);
                        setSelectedProduct(null);
                      }}
                      className="px-6 py-3 bg-tennis-dark text-white font-oswald uppercase tracking-wider rounded-lg transition-all duration-300 hover:bg-tennis-accent"
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
