import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Search, Filter, MapPin, Trophy, TrendingUp, Calendar } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

const playersData = [
  {
    id: 1,
    name: 'Emma Wilson',
    country: 'GBR',
    rank: 3,
    age: 24,
    titles: 12,
    image: '/player-1.jpg',
    bio: 'Rising star from Great Britain with a powerful serve and exceptional court coverage.',
    stats: { wins: 245, losses: 67, winRate: '78%' },
  },
  {
    id: 2,
    name: 'Alexander Kovac',
    country: 'SRB',
    rank: 1,
    age: 28,
    titles: 24,
    image: '/player-2.jpg',
    bio: 'World number one with unmatched consistency and mental toughness on the court.',
    stats: { wins: 412, losses: 89, winRate: '82%' },
  },
  {
    id: 3,
    name: 'Sofia Martinez',
    country: 'ESP',
    rank: 5,
    age: 22,
    titles: 8,
    image: '/player-3.jpg',
    bio: 'Spanish clay court specialist with incredible footwork and tactical intelligence.',
    stats: { wins: 198, losses: 76, winRate: '72%' },
  },
  {
    id: 4,
    name: 'James Park',
    country: 'USA',
    rank: 7,
    age: 26,
    titles: 15,
    image: '/player-4.jpg',
    bio: 'American powerhouse known for his aggressive baseline game and big serves.',
    stats: { wins: 287, losses: 112, winRate: '72%' },
  },
  {
    id: 5,
    name: 'Yuki Tanaka',
    country: 'JPN',
    rank: 12,
    age: 23,
    titles: 6,
    image: '/player-5.jpg',
    bio: 'Japanese sensation with lightning-fast reflexes and precise shot placement.',
    stats: { wins: 176, losses: 89, winRate: '66%' },
  },
  {
    id: 6,
    name: 'Marcus Chen',
    country: 'USA',
    rank: 2,
    age: 25,
    titles: 18,
    image: '/player-6.jpg',
    bio: 'All-court player with exceptional versatility and strategic game planning.',
    stats: { wins: 334, losses: 98, winRate: '77%' },
  },
];

export default function Players() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPlayer, setSelectedPlayer] = useState<typeof playersData[0] | null>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.player-card',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'expo.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const filteredPlayers = playersData.filter(player =>
    player.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="pt-20 min-h-screen bg-[#f6f6f6]">
      {/* Header */}
      <div className="bg-tennis-dark py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="font-oswald text-4xl md:text-5xl font-bold text-white uppercase mb-4">
            Player Profiles
          </h1>
          <p className="text-white/70 max-w-lg">
            Meet the world-class athletes competing at this year's Grand Slam Championship.
          </p>
        </div>
      </div>

      {/* Content */}
      <div ref={sectionRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Search */}
        <div className="flex flex-col md:flex-row md:items-center gap-4 mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search players..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-3 w-full border border-gray-200 rounded-lg focus:ring-2 focus:ring-tennis-accent focus:border-transparent outline-none"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-3 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
            <Filter className="w-5 h-5" />
            <span>Filter</span>
          </button>
        </div>

        {/* Players Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlayers.map((player) => (
            <div
              key={player.id}
              className="player-card group bg-white rounded-2xl shadow-lg overflow-hidden cursor-pointer transition-all duration-500 hover:-translate-y-2 hover:shadow-xl"
              onClick={() => setSelectedPlayer(player)}
            >
              {/* Image */}
              <div className="relative h-72 overflow-hidden">
                <img
                  src={player.image}
                  alt={player.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-tennis-dark via-transparent to-transparent" />
                
                {/* Rank Badge */}
                <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 bg-white/90 backdrop-blur-sm rounded-full">
                  <TrendingUp className="w-4 h-4 text-tennis-accent" />
                  <span className="font-oswald text-sm font-semibold text-tennis-dark">
                    Rank #{player.rank}
                  </span>
                </div>

                {/* Player Info */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="font-oswald text-2xl text-white uppercase mb-1">
                    {player.name}
                  </h3>
                  <div className="flex items-center gap-2 text-white/70">
                    <MapPin className="w-4 h-4" />
                    <span>{player.country}</span>
                  </div>
                </div>
              </div>

              {/* Stats Preview */}
              <div className="p-6 grid grid-cols-3 gap-4">
                <div className="text-center">
                  <Trophy className="w-5 h-5 mx-auto mb-1 text-tennis-gold" />
                  <p className="font-oswald text-lg text-tennis-dark">{player.titles}</p>
                  <p className="text-xs text-gray-500">Titles</p>
                </div>
                <div className="text-center">
                  <Calendar className="w-5 h-5 mx-auto mb-1 text-tennis-accent" />
                  <p className="font-oswald text-lg text-tennis-dark">{player.age}</p>
                  <p className="text-xs text-gray-500">Age</p>
                </div>
                <div className="text-center">
                  <TrendingUp className="w-5 h-5 mx-auto mb-1 text-green-500" />
                  <p className="font-oswald text-lg text-tennis-dark">{player.stats.winRate}</p>
                  <p className="text-xs text-gray-500">Win Rate</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Player Detail Dialog */}
      <Dialog open={!!selectedPlayer} onOpenChange={() => setSelectedPlayer(null)}>
        <DialogContent className="max-w-2xl">
          {selectedPlayer && (
            <>
              <DialogHeader>
                <DialogTitle className="font-oswald text-2xl uppercase">
                  Player Profile
                </DialogTitle>
              </DialogHeader>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <img
                    src={selectedPlayer.image}
                    alt={selectedPlayer.name}
                    className="w-full h-64 object-cover rounded-xl"
                  />
                </div>
                <div>
                  <h2 className="font-oswald text-2xl text-tennis-dark uppercase mb-2">
                    {selectedPlayer.name}
                  </h2>
                  <div className="flex items-center gap-2 text-gray-600 mb-4">
                    <MapPin className="w-4 h-4" />
                    <span>{selectedPlayer.country}</span>
                  </div>
                  <p className="text-gray-600 mb-6">{selectedPlayer.bio}</p>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-tennis-light p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Current Rank</p>
                      <p className="font-oswald text-2xl text-tennis-dark">#{selectedPlayer.rank}</p>
                    </div>
                    <div className="bg-tennis-light p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Career Titles</p>
                      <p className="font-oswald text-2xl text-tennis-dark">{selectedPlayer.titles}</p>
                    </div>
                    <div className="bg-tennis-light p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Career Wins</p>
                      <p className="font-oswald text-2xl text-tennis-dark">{selectedPlayer.stats.wins}</p>
                    </div>
                    <div className="bg-tennis-light p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Win Rate</p>
                      <p className="font-oswald text-2xl text-tennis-dark">{selectedPlayer.stats.winRate}</p>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
