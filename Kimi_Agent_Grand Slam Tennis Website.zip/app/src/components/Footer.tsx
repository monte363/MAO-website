import { Link } from 'react-router-dom';
import { Trophy, Facebook, Twitter, Instagram, Youtube, MapPin, Phone, Mail, Clock } from 'lucide-react';

const quickLinks = [
  { path: '/', label: 'Home' },
  { path: '/players', label: 'Players' },
  { path: '/scores', label: 'Scores' },
  { path: '/shop', label: 'Shop' },
  { path: '/contact', label: 'Contact' },
];

const tournamentLinks = [
  { path: '/calendar', label: 'Schedule' },
  { path: '/rankings', label: 'Rankings' },
  { path: '/sponsors', label: 'Sponsors' },
  { path: '#', label: 'FAQs' },
  { path: '#', label: 'Accessibility' },
];

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Youtube, href: '#', label: 'YouTube' },
];

export default function Footer() {
  return (
    <footer className="bg-tennis-dark text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="p-2 bg-tennis-gold/20 rounded-lg">
                <Trophy className="w-8 h-8 text-tennis-gold" />
              </div>
              <div className="flex flex-col">
                <span className="font-oswald font-bold text-xl leading-tight">
                  GRAND SLAM
                </span>
                <span className="text-xs font-oswald uppercase tracking-wider text-tennis-gold">
                  Championship
                </span>
              </div>
            </Link>
            <p className="text-white/70 text-sm leading-relaxed">
              The pinnacle of tennis excellence. Experience world-class competition 
              and witness history in the making at the most prestigious tournament 
              in professional tennis.
            </p>
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="p-2.5 bg-white/10 rounded-lg transition-all duration-300 hover:bg-tennis-gold hover:text-tennis-dark hover:rotate-[360deg]"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-oswald text-lg uppercase tracking-wider mb-6 text-tennis-gold">
              Quick Links
            </h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-white/70 text-sm transition-all duration-300 hover:text-tennis-gold hover:translate-x-1 inline-block"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Tournament Info */}
          <div>
            <h3 className="font-oswald text-lg uppercase tracking-wider mb-6 text-tennis-gold">
              Tournament Info
            </h3>
            <ul className="space-y-3">
              {tournamentLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.path}
                    className="text-white/70 text-sm transition-all duration-300 hover:text-tennis-gold hover:translate-x-1 inline-block"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-oswald text-lg uppercase tracking-wider mb-6 text-tennis-gold">
              Contact Us
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-tennis-gold flex-shrink-0 mt-0.5" />
                <span className="text-white/70 text-sm">
                  123 Championship Drive<br />
                  Tennis Valley, CA 90210
                </span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-tennis-gold flex-shrink-0" />
                <span className="text-white/70 text-sm">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-tennis-gold flex-shrink-0" />
                <span className="text-white/70 text-sm">info@grandslam.com</span>
              </li>
              <li className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-tennis-gold flex-shrink-0" />
                <span className="text-white/70 text-sm">Mon - Fri: 9AM - 6PM</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/50 text-sm text-center md:text-left">
              © 2026 Grand Slam Championship. All rights reserved.
            </p>
            <div className="flex gap-6">
              <Link to="#" className="text-white/50 text-sm hover:text-tennis-gold transition-colors">
                Privacy Policy
              </Link>
              <Link to="#" className="text-white/50 text-sm hover:text-tennis-gold transition-colors">
                Terms of Service
              </Link>
              <Link to="#" className="text-white/50 text-sm hover:text-tennis-gold transition-colors">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
