import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Trophy } from 'lucide-react';

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/rankings', label: 'Rankings' },
  { path: '/players', label: 'Players' },
  { path: '/scores', label: 'Scores' },
  { path: '/calendar', label: 'Calendar' },
  { path: '/shop', label: 'Shop' },
  { path: '/sponsors', label: 'Sponsors' },
  { path: '/contact', label: 'Contact' },
];

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className={`p-2 rounded-lg transition-all duration-300 ${
              isScrolled ? 'bg-tennis-dark' : 'bg-white/20 backdrop-blur-sm'
            }`}>
              <Trophy className={`w-6 h-6 transition-colors duration-300 ${
                isScrolled ? 'text-tennis-gold' : 'text-white'
              } group-hover:text-tennis-gold`} />
            </div>
            <div className="flex flex-col">
              <span className={`font-oswald font-bold text-lg leading-tight transition-colors duration-300 ${
                isScrolled ? 'text-tennis-dark' : 'text-white'
              }`}>
                GRAND SLAM
              </span>
              <span className={`text-xs font-oswald uppercase tracking-wider transition-colors duration-300 ${
                isScrolled ? 'text-tennis-accent' : 'text-tennis-gold'
              }`}>
                Championship
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`relative px-4 py-2 font-oswald text-sm uppercase tracking-wider transition-all duration-300 group ${
                  isScrolled
                    ? 'text-tennis-dark hover:text-tennis-accent'
                    : 'text-white/90 hover:text-white'
                } ${location.pathname === link.path ? 'font-semibold' : ''}`}
              >
                {link.label}
                <span className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-0.5 transition-all duration-300 group-hover:w-4/5 ${
                  isScrolled ? 'bg-tennis-accent' : 'bg-tennis-gold'
                } ${location.pathname === link.path ? 'w-4/5' : ''}`} />
              </Link>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden lg:block">
            <Link
              to="/scores"
              className={`px-6 py-2.5 font-oswald text-sm uppercase tracking-wider rounded transition-all duration-300 ${
                isScrolled
                  ? 'bg-tennis-dark text-white hover:bg-tennis-accent'
                  : 'bg-white/20 backdrop-blur-sm text-white border border-white/30 hover:bg-white/30'
              }`}
            >
              Live Scores
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`lg:hidden p-2 rounded-lg transition-colors duration-300 ${
              isScrolled ? 'text-tennis-dark' : 'text-white'
            }`}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`lg:hidden overflow-hidden transition-all duration-500 ${
            isMobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
          }`}
        >
          <div className="py-4 space-y-1 bg-white/95 backdrop-blur-md rounded-lg mb-4 shadow-lg">
            {navLinks.map((link, index) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block px-6 py-3 font-oswald text-sm uppercase tracking-wider transition-all duration-300 ${
                  location.pathname === link.path
                    ? 'bg-tennis-dark text-white'
                    : 'text-tennis-dark hover:bg-tennis-light hover:text-tennis-accent'
                }`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      </nav>
    </header>
  );
}
